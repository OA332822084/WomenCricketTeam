package com.example.womencricketteam;

import java.io.Serializable;

public class Cricketers implements Serializable {
    String cricketer,role;
    int cricketImage;

    public Cricketers(int cricketImage) {
        this.cricketImage = cricketImage;
    }

    public int getCricketImage() {
        return cricketImage;
    }

    public void setCricketImage(int cricketImage) {
        this.cricketImage = cricketImage;
    }

    public Cricketers(String cricketer, String role) {
        this.cricketer = cricketer;
        this.role = role;
    }

    public Cricketers() {
    }

    public String getCricketer() {
        return cricketer;
    }

    public void setCricketer(String cricketer) {
        this.cricketer = cricketer;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}

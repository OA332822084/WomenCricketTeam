package com.example.womencricketteam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner spinner;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    String players,roles;
    TeamAdapter teamAdapter;
    RecyclerView recyclerView;
    ArrayList<Cricketers>  cricketers;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        spinner = findViewById(R.id.name_spinner);
        spinner = findViewById(R.id.role_spinner);
        recyclerView  = findViewById(R.id.recycler_id);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Cricketers");
        loadData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.addmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @SuppressLint("ResourceType")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Spinner cricketer,role;
        Button add;
        switch (item.getItemId()){
            case R.id.add_id:
                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.add_player);
                dialog.show();
                cricketer = dialog.findViewById(R.id.name_spinner);
                role = dialog.findViewById(R.id.role_spinner);
                ArrayAdapter<CharSequence> array=ArrayAdapter.createFromResource(getApplicationContext(),R.array.names_array, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                cricketer.setAdapter(array);
                cricketer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                     players=cricketer.getItemAtPosition(position).toString();
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
                ArrayAdapter<CharSequence> array1=ArrayAdapter.createFromResource(getApplicationContext(),R.array.roles_array, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                role.setAdapter(array1);
                role.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        roles=role.getItemAtPosition(position).toString();
                    }
                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
               add= dialog.findViewById(R.id.add_btn);
               add.setOnClickListener(new View.OnClickListener() {
                   @Override
                   public void onClick(View v) {
                       addDataToFirebase(players,roles);
                       dialog.dismiss();
                       loadData();
                   }
               });
               break;

        }
        return super.onOptionsItemSelected(item);
    }

    private void loadData() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cricketers=new ArrayList<>();
                for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                    Cricketers teamCricketers=dataSnapshot.getValue(Cricketers.class);
                    cricketers.add(teamCricketers);
                }
                teamAdapter = new TeamAdapter(getApplicationContext(),cricketers);
                recyclerView.setAdapter(teamAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void addDataToFirebase(String players, String roles) {
        Cricketers cricketers = new Cricketers(players,roles);
        databaseReference.push().setValue(cricketers);
    }
}
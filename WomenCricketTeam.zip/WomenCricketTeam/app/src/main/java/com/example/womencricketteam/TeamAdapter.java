package com.example.womencricketteam;

import static com.google.android.material.color.utilities.MaterialDynamicColors.error;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TeamAdapter extends RecyclerView.Adapter<TeamAdapter.MyViewHolder> {
    Context context;
    ArrayList<Cricketers> cricketers;
    int currentPosition;
    DatabaseReference databaseReference;

    public TeamAdapter(Context context, ArrayList<Cricketers> cricketers) {
        this.context = context;
        this.cricketers = cricketers;
    }

    @NonNull
    @Override
    public TeamAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TeamAdapter.MyViewHolder holder, int position) {
        Cricketers cricketers1 = cricketers.get(position);
        holder.cricket_tv.setText(cricketers1.getCricketer());
        holder.role_tv.setText(cricketers1.getRole());
        if (cricketers1.getRole().equals("All Rounder")) {
            holder.img_iv.setImageResource(R.drawable.batball);
        }
        if (cricketers1.getRole().equals("Batsman")) {
            holder.img_iv.setImageResource(R.drawable.bat);
        }
        if (cricketers1.getRole().equals("Bowler")) {
            holder.img_iv.setImageResource(R.drawable.ball);
        }
        if (cricketers1.getRole().equals("WicketKeeper")) {
            holder.img_iv.setImageResource(R.drawable.wicketkeeper);
        }

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                PopupMenu popupMenu = new PopupMenu(context,v);
                currentPosition =holder.getAdapterPosition();
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if(item.getItemId()==R.id.edit_id){
                            editTeam();
                        }else if(item.getItemId()==R.id.delete_id){
                            deleteTeam();
                        }
                        return true;
                    }
                });
                popupMenu.show();
                return true;
            }

        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(context,PlayersView.class);
                in.putExtra("Players",cricketers1);
                v.getContext().startActivity(in);
            }
        });
    }
    private void editTeam(){
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.add_player);
    }
    private void deleteTeam(){
        Cricketers cricketers2 = cricketers.get(currentPosition);
        databaseReference = FirebaseDatabase.getInstance().getReference("Cricketers");
        Query query = databaseReference.orderByChild("cricketer").equalTo(cricketers2.getCricketer());
    query.addListenerForSingleValueEvent(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            for(DataSnapshot dataSnapshot:snapshot.getChildren()){
                dataSnapshot.getRef().removeValue();
                notifyDataSetChanged();
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    });
    }

   @Override
    public int getItemCount() {
        return cricketers.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cricket_tv,role_tv;
        ImageView img_iv;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cricket_tv = itemView.findViewById(R.id.cricketer_name);
            role_tv = itemView.findViewById(R.id.cricketer_role);
            img_iv = itemView.findViewById(R.id.img_id);
        }
    }
}


package com.example.womencricketteam;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PlayersView extends AppCompatActivity {
    TextView cricketer_tv, role_tv;
    ImageView cricketImage;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players_view);

        cricketer_tv = findViewById(R.id.name_id);
        role_tv = findViewById(R.id.role_id);
        cricketImage = findViewById(R.id.img_viw_id);

        Intent in = getIntent();
        Cricketers cricketers = (Cricketers) in.getSerializableExtra("Players");
        cricketer_tv.setText(cricketers.getCricketer());
        role_tv.setText(cricketers.getRole());
        if (cricketers.getRole().equals("All Rounder")) {
            cricketImage.setImageResource(R.drawable.batball);
        }
        if (cricketers.getRole().equals("Batsman")) {
            cricketImage.setImageResource(R.drawable.bat);
        }
        if (cricketers.getRole().equals("Bowler")) {
            cricketImage.setImageResource(R.drawable.ball);
        }
        if (cricketers.getRole().equals("WicketKeeper")) {
            cricketImage.setImageResource(R.drawable.wicketkeeper);
        }

    }
}
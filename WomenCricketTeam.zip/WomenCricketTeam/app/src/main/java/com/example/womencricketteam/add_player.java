package com.example.womencricketteam;

public class add_player {
    String teamName,role;

}
